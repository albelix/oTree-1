1. Results page
2. Blocker between two parts
3. Comprehension questions
4. Debug blocks shown on city pages and on results pages
5. Move result vars to participant.vars
6. Dump participant.vars and decision objects to main table
7. Export module for custom tables
